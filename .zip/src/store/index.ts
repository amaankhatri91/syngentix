import store from './storeSetup'
export * from './rootReducer'
export * from './hook'
export default store
