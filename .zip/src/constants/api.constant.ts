export const TOKEN_TYPE = 'Bearer'
export const REQUEST_HEADER_AUTH_KEY = 'Authorization'
