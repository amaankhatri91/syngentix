export const APP_NAME = 'Syngentix'
export const PERSIST_STORE_NAME = 'auth'
export const REDIRECT_URL_KEY = 'redirectUrl'