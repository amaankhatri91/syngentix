import React from "react";

const Templates = () => {
  return (
    <div className="">
      <h1>Templates</h1>
    </div>
  );
};

export default Templates;












