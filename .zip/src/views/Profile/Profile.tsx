import React from "react";

const Profile = () => {
  return (
    <div className="">
      <h1>Profile</h1>
    </div>
  );
};

export default Profile;











