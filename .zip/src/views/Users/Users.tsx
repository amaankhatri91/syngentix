import UserList from "./UserList";

const Users = () => {
  return <UserList />;
};

export default Users;
