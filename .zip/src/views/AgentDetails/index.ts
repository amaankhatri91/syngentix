import AgentDetails from "./AgentDetails";

export default AgentDetails;
