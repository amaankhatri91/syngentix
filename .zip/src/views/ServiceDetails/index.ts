import ServiceDetails from "./ServiceDetails";

export default ServiceDetails;

