import FilesList from "./FilesList";

const Files = () => {
  return <FilesList />;
};

export default Files;
