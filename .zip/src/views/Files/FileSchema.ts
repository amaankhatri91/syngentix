import * as Yup from "yup";

export const FileSchema = Yup.object().shape({
  title: Yup.string()
    .required("Required")
    .min(2, "must be at least 2 characters")
    .max(100, "must not exceed 100 characters"),
  description: Yup.string(),
  content: Yup.string(),
  isSearchable: Yup.boolean(),
  isAlwaysOn: Yup.boolean(),
});

