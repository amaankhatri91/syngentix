import React from "react";
import { useAppSelector, useAppDispatch } from "@/store";
import { setSidebarOpen, setTheme } from "@/store/auth/authSlice";
import useTheme from "@/utils/hooks/useTheme";
import { sidebarIcon } from "@/utils/logoUtils";
import { SearchInput } from "@/components/SearchInput";
import darkSwitchIcon from "@/assets/switchIcon/dark-switch.svg";
import lightSwitchIcon from "@/assets/switchIcon/light-switch.svg";

const Header: React.FC = () => {
  const { sidebarOpen, userName } = useAppSelector((state) => state.auth);
  const { theme, isDark } = useTheme();
  const dispatch = useAppDispatch();

  const handleThemeToggle = () => {
    const newTheme = isDark ? "light" : "dark";
    dispatch(setTheme(newTheme));
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 h-20 z-10 transition-all  duration-300 ${
        sidebarOpen ? "lg:left-56" : "lg:left-16"
      }`}
    >
      <div className="flex items-center justify-between h-full px-6">
        <div className="flex gap-5 items-center">
          <button
            onClick={() => {
              dispatch(setSidebarOpen(!sidebarOpen));
            }}
            className="flex-1 max-w-md"
          >
            <img src={sidebarIcon(sidebarOpen)} alt="icon" />
          </button>
          <div>
            <h3 className="text-lg font-medium">Welcome, {userName}</h3>
            <span className="text-sm">Create your workspace</span>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={handleThemeToggle}
            aria-label={`Switch to ${isDark ? "light" : "dark"} mode`}
            className="relative flex items-center justify-center"
          >
            <img
              key={theme}
              src={isDark ? darkSwitchIcon : lightSwitchIcon}
              alt={isDark ? "Dark mode" : "Light mode"}
              className="
                h-8 object-contain
                transition-all duration-500 ease-in-out
                opacity-100 scale-100
              "
            />
          </button>
          <SearchInput
            placeholder="Search for..."
            onSearch={(value) => {
              // Handle debounced search here
              console.log("Searching for:", value);
            }}
            className="text-sm text-[#0C1116]"
            debounceDelay={300}
          />
        </div>
      </div>
    </header>
  );
};

export default Header;
