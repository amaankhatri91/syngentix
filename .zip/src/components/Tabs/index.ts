export { default } from "./Tabs";
export type { TabsProps, TabItem } from "./Tabs";

