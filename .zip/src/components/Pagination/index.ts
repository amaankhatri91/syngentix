export { default } from "./Pagination";
export type { PaginationProps } from "./Pagination";


