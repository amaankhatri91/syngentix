import Breadcrumb from "./Breadcrumb";

export default Breadcrumb;
