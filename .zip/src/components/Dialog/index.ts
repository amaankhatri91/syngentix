export { default as Dialog } from "./Dialog";
export type { DialogProps } from "./Dialog";

