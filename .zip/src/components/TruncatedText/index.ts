export { default } from "./TruncatedText";

