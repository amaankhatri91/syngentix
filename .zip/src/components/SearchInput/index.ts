export { default as SearchInput } from "./SearchInput";
export type { SearchInputProps } from "./SearchInput";

