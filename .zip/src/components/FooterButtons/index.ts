export { default as FooterButtons } from "./FooterButtons";
export type { FooterButtonsProps } from "./FooterButtons";








