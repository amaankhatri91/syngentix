import React from "react";

interface CalendarIconProps {
  color?: string;
  size?: number;
}

const CalendarIcon: React.FC<CalendarIconProps> = ({
  color = "#BDC9F5",
  size = 16,
}) => {
  return (
    <svg
      width="18"
      height="18"
      viewBox="0 0 18 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g clip-path="url(#clip0_631_13212)">
        <path
          d="M6 9H4.5C3.67275 9 3 9.67275 3 10.5V12C3 12.8273 3.67275 13.5 4.5 13.5H6C6.82725 13.5 7.5 12.8273 7.5 12V10.5C7.5 9.67275 6.82725 9 6 9ZM4.5 12V10.5H6V12H4.5ZM14.25 1.5H13.5V0.75C13.5 0.336 13.1648 0 12.75 0C12.3352 0 12 0.336 12 0.75V1.5H6V0.75C6 0.336 5.66475 0 5.25 0C4.83525 0 4.5 0.336 4.5 0.75V1.5H3.75C1.68225 1.5 0 3.18225 0 5.25V14.25C0 16.3177 1.68225 18 3.75 18H14.25C16.3177 18 18 16.3177 18 14.25V5.25C18 3.18225 16.3177 1.5 14.25 1.5ZM3.75 3H14.25C15.4905 3 16.5 4.0095 16.5 5.25V6H1.5V5.25C1.5 4.0095 2.5095 3 3.75 3ZM14.25 16.5H3.75C2.5095 16.5 1.5 15.4905 1.5 14.25V7.5H16.5V14.25C16.5 15.4905 15.4905 16.5 14.25 16.5Z"
          fill="white"
        />
      </g>
      <defs>
        <clipPath id="clip0_631_13212">
          <rect width="18" height="18" fill="white" />
        </clipPath>
      </defs>
    </svg>
  );
};

export default CalendarIcon;

