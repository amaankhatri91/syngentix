// src/@types/material-tailwind.d.ts
// src/@types/material-tailwind.d.ts
declare module "@material-tailwind/react" {
    export const Menu: any;
    export const MenuHandler: any;
    export const MenuList: any;
    export const MenuItem: any;
    export const Button: any;
    export const Avatar: any;
    export const Input: any;
    export const Textarea: any;
    export const Card: any;
    export const CardHeader: any;
    export const CardBody: any;
    export const CardFooter: any;
    export const Typography: any;
    export const Skeleton: any;
    export const Badge: any;
    export const Dialog: any;
    export const DialogHeader: any;
    export const DialogBody: any;
    export const DialogFooter: any;
    export const Spinner: any;
}

