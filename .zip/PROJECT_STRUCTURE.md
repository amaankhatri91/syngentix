# Syngentix - Project Structure Overview

## Project Information
- **Project Name:** Syngentix
- **Technology Stack:** React 18 + TypeScript + Vite
- **UI Framework:** Material Tailwind
- **State Management:** Redux Toolkit
- **Build Tool:** Vite

---

## Project Structure

```
syngentix/
│
├── 📁 public/                    # Static assets served directly
│   └── Images & logos
│
├── 📁 src/                       # Main source code directory
│   │
│   ├── 📁 @types/                # TypeScript type definitions
│   │   ├── auth.ts              # Authentication types
│   │   ├── product.ts           # Product-related types
│   │   └── material-tailwind.d.ts
│   │
│   ├── 📁 assets/                # Static assets (images, icons, logos)
│   │   ├── background/          # Background images
│   │   ├── icons/               # Icon files
│   │   ├── logos/               # Brand logos (light/dark variants)
│   │   └── switchIcon/          # Theme switch icons
│   │
│   ├── 📁 components/            # Reusable UI components
│   │   ├── DataTable/           # Data table component with actions
│   │   ├── Icons/               # Custom icon components
│   │   ├── Layout/              # Layout components (Header, Sidebar)
│   │   └── SearchInput/         # Search input component
│   │
│   ├── 📁 configs/              # Application configuration
│   │   └── app.config.ts        # App-wide settings
│   │
│   ├── 📁 constants/            # Application constants
│   │   ├── api.constant.ts      # API endpoints
│   │   ├── app.constant.ts      # App constants
│   │   └── navigation.constant.ts # Navigation routes
│   │
│   ├── 📁 routes/                # Routing configuration
│   │   ├── index.ts
│   │   └── routes.tsx           # Route definitions
│   │
│   ├── 📁 services/              # API and business logic services
│   │   ├── ApiService.ts        # Base API service
│   │   ├── AuthService.ts       # Authentication service
│   │   ├── BaseService.ts       # Base service class
│   │   ├── ProductService.ts    # Product-related API calls
│   │   └── RtkQueryService.ts   # RTK Query service
│   │
│   ├── 📁 store/                 # Redux state management
│   │   ├── auth/                # Authentication state slice
│   │   ├── product/             # Product state slice
│   │   ├── hook.ts              # Redux hooks
│   │   ├── index.ts             # Store exports
│   │   ├── rootReducer.ts       # Root reducer
│   │   └── storeSetup.ts        # Store configuration
│   │
│   ├── 📁 utils/                 # Utility functions and helpers
│   │   ├── common.ts            # Common utilities
│   │   ├── deepParseJson.ts     # JSON parsing utilities
│   │   ├── logoUtils.ts         # Logo utility functions
│   │   └── hooks/                # Custom React hooks
│   │       ├── useAuth.ts       # Authentication hook
│   │       └── useThemeBackground.ts # Theme background hook
│   │
│   ├── 📁 views/                 # Page/View components
│   │   ├── Agents/              # Agents management page
│   │   ├── Auth/                # Authentication pages
│   │   │   └── SignIn/          # Sign-in page
│   │   ├── Dashboard/           # Dashboard page
│   │   ├── Profile/             # User profile page
│   │   ├── Settings/            # Settings page
│   │   ├── Templates/           # Templates page
│   │   └── Users/               # Users management page
│   │
│   ├── App.tsx                   # Main application component
│   ├── App.css                   # Global application styles
│   ├── main.tsx                  # Application entry point
│   └── index.css                 # Global CSS styles
│
├── 📄 Configuration Files
│   ├── package.json             # Dependencies and scripts
│   ├── tsconfig.json            # TypeScript configuration
│   ├── vite.config.ts           # Vite build configuration
│   ├── tailwind.config.js       # Tailwind CSS configuration
│   ├── postcss.config.js        # PostCSS configuration
│   └── eslint.config.js         # ESLint configuration
│
└── 📄 Documentation
    └── README.md                # Project documentation
```

---

## Key Features & Architecture

### **Frontend Framework**
- React 18 with TypeScript for type safety
- Vite for fast development and optimized builds

### **UI/UX**
- Material Tailwind for modern, responsive UI components
- Dark/Light theme support
- Custom icon components
- Reusable layout components (Header, Sidebar)

### **State Management**
- Redux Toolkit for centralized state management
- Redux Persist for state persistence
- Separate slices for Auth and Product domains

### **Data Management**
- RTK Query for efficient API data fetching
- Axios for HTTP requests
- Custom service layer for API abstraction

### **Routing**
- React Router DOM for client-side routing
- Protected routes for authentication

### **Form Handling**
- Formik for form management
- Yup for form validation

### **Data Display**
- TanStack React Table for advanced data tables
- Custom DataTable component with actions and status badges

### **Additional Features**
- Toast notifications (react-toastify)
- Search functionality with debouncing
- Custom hooks for common operations

---

## Main Application Pages/Views

1. **Dashboard** - Main dashboard view
2. **Agents** - Agent management interface
3. **Users** - User management interface
4. **Templates** - Template management
5. **Profile** - User profile settings
6. **Settings** - Application settings
7. **Sign In** - Authentication page

---

## Development Scripts

- `npm start` - Start development server
- `npm run build` - Build for production
- `npm run lint` - Run ESLint
- `npm run format` - Format code with Prettier and fix linting issues

---

## Environment Configuration

- API endpoint configured via `.env` file: `VITE_API_PREFIX`

---

*This document provides a high-level overview of the project structure. For detailed implementation, please refer to the source code.*






















